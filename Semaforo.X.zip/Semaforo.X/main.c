/*
 * File:   main_a.c
 * Author: aluno
 *
 * Created on 2 de Dezembro de 2022, 10:25
 */

#include "def_principais.h"
#include "lcd.h"
#include "proprias.h"

volatile int counter = 0; 
volatile unsigned char tick=FALSE;

int main(void){
//variaveis
config(); //configura��o dos perifericos
//inic_lcd(); // inicializa lcd
base_de_tempo();
sei();
//servo_pwm();

unsigned char estado = 0;
volatile unsigned int madrugada = 0;
// unsigned
//unsigned char maq_estados(unsigned char estado);
//char msg[TAM];
//unsigned char ctrl = 0;
//unsigned char ctrl2 = 0;
//unsigned char retorno = 0;

    while(1){
        
        if (tick==TRUE){
                counter++;
                madrugada++;
                tick=FALSE;
            }
        
        //if (madrugada > 36030) else 
        
        switch(estado){
            
            case 0:
                //Acionamento dos leds semaforo carro
                
                //SEM�FORO 1 carro
                set_bit(PORTC,PC3); // Liga luz verde
                clr_bit(PORTC,PC4); // Desliga luz amarela
                clr_bit(PORTC,PC5); // Desliga vermelha
                
                //SEM�FORO 2 carro
                //Acionamento dos leds semaforo carro
                clr_bit(PORTB,PB3); //  Desliga Luz verde
                clr_bit(PORTB,PB4); //  Desliga Luz amarela
                set_bit(PORTB,PB5); //  liga luz vermelha
               
                //SEM�FORO 3 carro
                clr_bit(PORTD,PD1); // desliga verde
                clr_bit(PORTD,PD0); // Desliga luz amarela
                set_bit(PORTC,PC6); // Liga luz vermelha
                
                 //SEM�FORO 4 carro
                //Acionamento dos leds semaforo carro
                set_bit(PORTB,PB7); //  Desliga Luz verde
                clr_bit(PORTD,PD5); //  Desliga Luz amarela
                clr_bit(PORTD,PD6); //  liga luz vermelha
                
                //Acionamento dos leds semaforo pedestre
                //SEM�FORO 1 Pedestre
                set_bit(PORTC,PC2);// liga Luz vermelha
                clr_bit(PORTC,PC1); // Desliga luz verde
                
                //SEM�FORO 2 Pedestre
                
                set_bit(PORTB,PB2);// liga luz vermelha
                clr_bit(PORTB,PB1);// desliga luz verde 
               
                //SEM�FORO 3 Pedestre
                set_bit(PORTD,PD2); // liga luz vermelha
                clr_bit(PORTD,PD3);// desliga Luz verde
                
                //SEM�FORO 4 Pedestre
                
                set_bit(PORTD,PD7);// Liga luz vermelha
                clr_bit(PORTB,PB0);// Desliga luz verde
                
                
                if(counter>6000){
                    estado=1;
                    counter=0;
                }
                break;
                
            case 1:
                //Acionamento dos leds semaforo carro
                
                //SEM�FORO 1 Carro
                clr_bit(PORTC,PC3); //  Desliga luz verde
                set_bit(PORTC,PC4); //  Liga luz amarela
                clr_bit(PORTC,PC5); //  Desliga luz vermelha
                
                //SEM�FORO 2 Carro
                clr_bit(PORTB,PB3); //  desliga luz verde
                clr_bit(PORTB,PB4); //  Desliga luz amarela
                set_bit(PORTB,PB5); //  liga luz vermelha
                        
                //SEM�FORO 3 carro
                clr_bit(PORTD,PD0); // Desliga luz amarela
                clr_bit(PORTD,PD1); // desliga verde
                set_bit(PORTC,PC6); // Liga luz vermelha
                
                 //SEM�FORO 4 carro
                //Acionamento dos leds semaforo carro
                set_bit(PORTB,PB7); //  liga Luz vermelha
                clr_bit(PORTD,PD5); //  Desliga Luz amarela
                clr_bit(PORTD,PD6); //  desliga luz verde
                
                if(counter>4000){
                    estado=2;
                    counter=0;
                }
                
                break;
                
            case 2:
                //Acionamento dos leds semaforo carro
                
                //SEM�FARO 1 Carro 
                set_bit(PORTC,PC5); //  Liga luz vermelho
                clr_bit(PORTC,PC3); //  Desliga luz verde
                clr_bit(PORTC,PC4); //  Desliga luz amarela
                
                //SEM�FARO 2 Carro
                //Acionamento dos leds semaforo carro
                set_bit(PORTB,PB3); //  liga luz verde
                clr_bit(PORTB,PB4); //  desliga luz amarela
                clr_bit(PORTB,PB5); //  desLiga luz vermelho
                
                //SEM�FORO 3 carro
                set_bit(PORTC,PC6); // Liga luz vermelha
                clr_bit(PORTD,PD0); // Desliga luz amarela
                clr_bit(PORTD,PD1); // desliga luz verde
                
                 //SEM�FORO 4 carro
                //Acionamento dos leds semaforo carro
                clr_bit(PORTB,PB7); //  liga Luz vermelha
                clr_bit(PORTD,PD5); //  Desliga Luz amarela
                set_bit(PORTD,PD6); //  desliga luz verde
                
                if(counter>6000){
                    estado=3;
                    counter=0;
                }
                break;
            case 3:
                
                //SEM�FARO 1 Carro 
                set_bit(PORTC,PC5); //  Liga luz vermelho
                clr_bit(PORTC,PC3); //  Desliga luz verde
                clr_bit(PORTC,PC4); //  Desliga luz amarela
                
                //SEM�FARO 2 Carro
                //Acionamento dos leds semaforo carro
                clr_bit(PORTB,PB3); //  desliga luz verde
                set_bit(PORTB,PB4); //  liga luz amarela
                clr_bit(PORTB,PB5); //  desLiga luz vermelho
                
                //SEM�FORO 3 carro
                set_bit(PORTC,PC6); // Liga luz vermelha
                clr_bit(PORTD,PD0); // Desliga luz amarela
                clr_bit(PORTD,PD1); // desliga luz verde
                
                 //SEM�FORO 4 carro
                //Acionamento dos leds semaforo carro
                clr_bit(PORTB,PB7); //  desliga Luz vermelha
                set_bit(PORTD,PD5); //  liga Luz amarela
                clr_bit(PORTD,PD6); //  desliga luz verde
                
                if(counter>4000){
                    estado=4;
                    counter=0;
                }
                break;   
                
            case 4:
                
                //SEM�FARO 1 Carro 
                set_bit(PORTC,PC5); //  Liga luz vermelho
                clr_bit(PORTC,PC4); //  Desliga luz amarela
                clr_bit(PORTC,PC3); //  Desliga luz verde
                
                //SEM�FARO 2 Carro
                //Acionamento dos leds semaforo carro
                set_bit(PORTB,PB5); //  Liga luz vermelho
                clr_bit(PORTB,PB4); //  desliga luz amarela
                clr_bit(PORTB,PB3); //  desliga luz verde
                
                
                //SEM�FORO 3 carro
                clr_bit(PORTC,PC6); // desLiga luz vermelha
                clr_bit(PORTD,PD0); // Desliga luz amarela
                set_bit(PORTD,PD1); // liga luz verde
                
                 //SEM�FORO 4 carro
                //Acionamento dos leds semaforo carro
                set_bit(PORTB,PB7); //  liga Luz vermelha
                clr_bit(PORTD,PD5); //  desliga Luz amarela
                clr_bit(PORTD,PD6); //  desliga luz verde
                
                if(counter>6000){
                    estado=5;
                    counter=0;
                }
                break;
                
            case 5:
                
                //SEM�FARO 1 Carro 
                set_bit(PORTC,PC5); //  Liga luz vermelho
                clr_bit(PORTC,PC4); //  Desliga luz amarela
                clr_bit(PORTC,PC3); //  Desliga luz verde
                
                //SEM�FARO 2 Carro
                //Acionamento dos leds semaforo carro
                set_bit(PORTB,PB5); //  Liga luz vermelho
                clr_bit(PORTB,PB4); //  desliga luz amarela
                clr_bit(PORTB,PB3); //  desliga luz verde
                         
                //SEM�FORO 3 carro
                clr_bit(PORTC,PC6); // desLiga luz vermelha
                set_bit(PORTD,PD0); // liga luz amarela
                clr_bit(PORTD,PD1); // desliga luz verde
                
                 //SEM�FORO 4 carro
                //Acionamento dos leds semaforo carro
                set_bit(PORTB,PB7); //  liga Luz vermelha
                clr_bit(PORTD,PD5); //  desliga Luz amarela
                clr_bit(PORTD,PD6); //  desliga luz verde
                
                if(counter>4000){
                    estado=6;
                    counter=0;
                }
                break;
                
            case 6:
                
                //SEM�FARO 1 Carro 
                set_bit(PORTC,PC5); //  Liga luz vermelho
                clr_bit(PORTC,PC4); //  Desliga luz amarela
                clr_bit(PORTC,PC3); //  Desliga luz verde
                
                //SEM�FARO 2 Carro
                //Acionamento dos leds semaforo carro
                set_bit(PORTB,PB5); //  Liga luz vermelho
                clr_bit(PORTB,PB4); //  desliga luz amarela
                clr_bit(PORTB,PB3); //  desliga luz verde
                         
                //SEM�FORO 3 carro
                set_bit(PORTC,PC6); // Liga luz vermelha
                clr_bit(PORTD,PD0); // desliga luz amarela
                clr_bit(PORTD,PD1); // desliga luz verde
                
                 //SEM�FORO 4 carro
                //Acionamento dos leds semaforo carro
                set_bit(PORTB,PB7); //  liga Luz vermelha
                clr_bit(PORTD,PD5); //  desliga Luz amarela
                clr_bit(PORTD,PD6); //  desliga luz verde
                
            
                //Acionamento dos leds semaforo pedestre
                //SEM�FORO 1 Pedestre
                clr_bit(PORTC,PC2);// desliga Luz vermelha
                set_bit(PORTC,PC1);// liga luz verde
                
                //SEM�FORO 2 Pedestre
                
                clr_bit(PORTB,PB2);// desliga luz vermelha
                set_bit(PORTB,PB1);// Liga luz verde
               
                //SEM�FORO 3 Pedestre
                clr_bit(PORTD,PD2); // desliga luz vermelha
                set_bit(PORTD,PD3);// liga Luz verde
                
                //SEM�FORO 4 Pedestre
                
                clr_bit(PORTD,PD7);// desliga luz vermelha
                set_bit(PORTB,PB0);// liga luz verde
                
                if(counter>5000){
                    estado=7;
                    counter=0;
                }
                break;
                
            case 7:
                
                //Acionamento dos leds semaforo pedestre
                //SEM�FORO 1 Pedestre
                tgl_bit(PORTC,PC1);// liga luz verde
                _delay_ms(300);
                tgl_bit(PORTC,PC1);// liga luz verde
                
                //SEM�FORO 2 Pedestre
                tgl_bit(PORTB,PB1);// Liga luz vermelha 
                _delay_ms(300);
                tgl_bit(PORTB,PB1);// Liga luz vermelha

                //SEM�FORO 3 Pedestre
                tgl_bit(PORTD,PD3);// liga luz verde
                _delay_ms(300);
                tgl_bit(PORTD,PD3);// liga luz verde
                
                //SEM�FORO 4 Pedestre
                tgl_bit(PORTB,PB0);// Liga luz verde
                _delay_ms(300);
                tgl_bit(PORTB,PB0);// Desliga luz vermelha
                   
                if(counter>50){
                    counter=0;
                    estado=0;   
                }
                break;
        }
    }
}

/*
 
 //Acionamento dos leds semaforo pedestre
                set_bit(PORTB,PB5); // Luz verde
                set_bit(PORTB,PB2); // Luz vermelha
                if(counter>5000)
                    estado=1;        
 *  caso 3:
 *              //SEM�FARO 1 Pedestre
                //Acionamento dos leds semaforo pedestre
                clr_bit(PORTC,PC2); //  Desliga luz vermelha
                set_bit(PORTC,PC1); // liga Luz verde
                
                //SEM�FARO 2 Pedestre
                //Acionamento dos leds semaforo pedestre
                set_bit(PORTB,PB2); // liga Luz verde 
                clr_bit(PORTB,PB1); // Desliga luz vermelha
                
                //SEM�FORO 3 Pedestre
                clr_bit(PORTD,PD2); // Desliga luz verde
                set_bit(PORTD,PD3);// liga Luz vermelha
                
                //SEM�FORO 4 Pedestre
                set_bit(PORTD,PD7);// Liga luz vermelha 
                clr_bit(PORTB,PB0);// Desliga luz verde
 
 */


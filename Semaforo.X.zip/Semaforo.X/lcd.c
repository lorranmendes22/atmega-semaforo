/*
 * File:   lcd.c
 * Author: aluno
 *
 * Created on 2 de Dezembro de 2022, 10:21
 */

#include "def_principais.h"
#include "lcd.h"
    
    /* Fun��es para o LCD*/
//---------------------------------------------------------------
// envia comandos ou caracteres para o LCD*/
// c: dados
// cd: instru��o ou caractere para o LCD (0 ou 1)
//---------------------------------------------------------------

void cmd_lcd(unsigned char c, char cd){
    if (cd==0)
        clr_bit(CONTR_LCD,RS);  // instru��o
    else
        set_bit(CONTR_LCD,RS);  // caractere
    
    // primeiro nibble de dados    
    DADOS_LCD = (DADOS_LCD & 0x0f)| (0xf0 & c);
    pulse_enable();
    
    // segundo nibble de dados    
    DADOS_LCD = (DADOS_LCD & 0x0f)| (0xf0 & (c<<4));
    pulse_enable();
    
    if((cd==0)&& (c<4)) // se for instru��o de retorno ou limpeza aguarda LCD pronto
        _delay_ms(2); 
}
//---------------------------------------------------------------
// Inicializa LCD*/
//---------------------------------------------------------------
void inic_lcd(){
    clr_bit(CONTR_LCD,RS);  // instru��o
    clr_bit(CONTR_LCD,E);  // ativa LCD
    _delay_ms(20); 
    
    DADOS_LCD = (DADOS_LCD & 0x0f)| 0x30;
    
    pulse_enable();
    _delay_ms(5); 
    pulse_enable();
    _delay_us(200); 
    pulse_enable();
    
    DADOS_LCD = (DADOS_LCD & 0x0f)| 0x20;
    
    pulse_enable();
    
    cmd_lcd(0x28,0); // interface 4 bits 2 linhas
    cmd_lcd(0x08,0); // desliga LCD
    cmd_lcd(0x01,0); // limpa LCD
    cmd_lcd(0x0c,0); // curso inativo n�o piscando
    cmd_lcd(0x80,0); // cursor na 1 linha, primeira posi��o a esquerda
    cmd_lcd(0xc0,0); // inserir caracter 2 linha
}
//---------------------------------------------------------------
// escreve RAM do LCD
//---------------------------------------------------------------
void escreve_lcd(char *c){
    for(;*c!=0; c++)
        cmd_lcd(*c,1);    
}
//---------------------------------------------------------------
// escreve RAM do LCD
//---------------------------------------------------------------
void escreve_lcd2(char *str){
    int i;
    for(i=0;str[i]!=0; i++)
        cmd_lcd(str[i],1);    
}
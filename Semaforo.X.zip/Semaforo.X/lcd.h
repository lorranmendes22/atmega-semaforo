/* 
 * File:   lcd.h
 * Author: aluno
 *
 * Created on 2 de Dezembro de 2022, 10:28
 */

#ifndef LCD_H
#define LCD_H

/* Macros display*/
#define DADOS_LCD  PORTD
#define CONTR_LCD  PORTB
#define E          PB1
#define RS         PB0

/* Gera��o de Pulso para o pino E */
#define pulse_enable() _delay_us(1); set_bit(CONTR_LCD,E); _delay_us(1); clr_bit(CONTR_LCD,E);_delay_us(45)

#define TAM_VETOR  5
#define CONV_ASCII 48

/*  Prototipos de fun��es  */
void cmd_lcd(unsigned char c, char cd);
void inic_lcd();
void escreve_lcd(char *c);
void escreve_lcd2(char *str);

#endif	/* LCD_H */
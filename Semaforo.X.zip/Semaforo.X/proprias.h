/* 
 * File:   def_principais.h
 * Author: aluno
 *
 * Created on 2 de Dezembro de 2022, 10:30
 */

#ifndef DEF_PROPRIAS_H
#define	DEF_PROPRIAS_H

#include "def_principais.h"
#include "lcd.h"

void config(void);
void servo_pwm(void);
void base_de_tempo(void);

//unsigned char maq_estados(unsigned char estado);
//ISR(PCINT1_vect);

#endif	/* PROPRIAS_H */
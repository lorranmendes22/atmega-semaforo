/*
 * File:   principais.c
 * Author: aluno
 *
 * Created on 2 de Dezembro de 2022, 10:21
 */

#include "def_principais.h"
#include "proprias.h"

void config(void){
/*------------------------configura como saida-----------------------------*/
    //Configura��o Semaforo
    
    DDRC = 0xff;
    DDRB = 0xff;
    DDRD = 0xff;
    
    //Configura��o Display
    //DDRD = 0xff;  // todos bits do port D como saida
    //set_bit(DDRB,PB0); // configura PB0 como saida
    //set_bit(DDRB,PB1); // configura PB1 como saida
    
    //Configura��o Motor_DC
    
    //Configura��o Servo Motor
    //set_bit(DDRB,PB2); //configura PB2 como saida
    
/*--------------------------Ativa pull up---------------------------------*/
    // Configura��o servo motor:
    //set_bit(PORTB,PB2); // ativa resistor de pull up do pino B2

    //Configura��o da cancela:
    //set_bit(PORTC,PC3); // ativa resistor de pull up do pino PC3 
    //set_bit(PORTC,PC4); // ativa resistor de pull up do pino PC3
    
    
/*---------------------------Interrup��es------------------------------------*/
    
    /*PCIE0 ? Habilita PCINT no PORTB -> PCINT[0:7];
      PCIE1 ? Habilita PCINT no PORTC -> PCINT[8:15];
      PCIE2 ? Habilita PCINT no PORTD -> PCINT[16:23];*/
    
    /*PCMSK0 ? Pin Change Mask Register 0 PCINT[0:7]
      PCMSK1 ? Pin Change Mask Register 1 PCINT[8:14]
      PCMSK2 ? Pin Change Mask Register 2 PCINT[16:23]
     
     Bit 7 ?  PCMSK1 Reserved 
     */
   
    //configura��o da Cancela:
    
    //set_bit(PCICR,1);     // Registrador que habilita as interrup��es no PORTC o PCIE1
    //set_bit(PCMSK1,PC3); // Habilita interrup��o no pino PC3
    //set_bit(PCMSK1,PC4); // Habilita interrup��o no pino PC4
    
    /*set_bit(PCINT11,PC3); //
    set_bit(PCINT12,PC4); */
}        

//Rotina de tratamento da interrup��o do port b
/*ISR(PCINT1_vect){
    if (!(PINC&(1<<PC3)))  //foi aciona PB2
        tgl_bit(PORTC,PD7);
        tgl_bit(PORTC,PD6);
}*/

void servo_pwm(void){
    ICR1 = TOP; //39999
    TCCR1A |= (1 << COM1B1) | (1 << WGM11); //OC1B n�o invertido em PB2
    TCCR1B |= (1 << WGM13) | (1 << WGM12)|(1 << CS11) ; //Fast PWM modo 14 e prescale = 8

}

void base_de_tempo(void){
    
    //TCNT0 = 0x00; // inicia i timer 0
    TCNT0 = 5; 
    TCCR0B |= (1 << CS01) | (1 << CS00); //PRESCALER IGUAL A 64
    TIMSK0 |= (1 << TOIE0);//HABILITA INTERRUP��O por ESTOURO DE TMR0
    
    //ciclo de m�quina = 1/16M = 62,5ns
    //estouro 255 para 5
    //tempo de estouro = 62,5 x 64 (prescaler) x 250 = 4,8ms
    
}

//Rotina de interrup��o
/*ISR(TIMER0_OVF_vect){
    counter++;
    if (counter==10000){ // led vai ser togado a cada 10 segundos
        tgl_bit(PORTC,PC5);
        counter=0;
    }
}*/

ISR(TIMER0_OVF_vect){
    tick=TRUE;
}